import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $("nav").show(0);
    $("footer").show(0);

    $(".exit").hide(0);
    $(".rightArrow").hide(0);
    $(".leftArrow").hide(0);

    let images = [];
    $(".winner").each(function () {
      images.push($(this).children("img").attr("src"));
    })

    $(".rightArrow").click(function () {
      let currentSrc = $(".pics").children().attr("src");
      let pos = 0;
      for (let i = 0; i < 10; i++) {
        if (images[i] == currentSrc) {
          if (i == 9) {
            pos = 0;
          } else {
            pos = i + 1;
          }
        }
      }
      $(".pics").html(`<img class="w-100" src="${images[pos]}">`);
    })

    $(".leftArrow").click(function () {
      let currentSrc = $(".pics").children().attr("src");
      let pos = 0;
      for (let i = 0; i < 10; i++) {
        if (images[i] == currentSrc) {
          if (i == 0) {
            pos = 9;
          } else {
            pos = i - 1;
          }
        }
      }
      $(".pics").html(`<img class="w-100" src="${images[pos]}">`);
    })

    $(document).keydown(function (e) {
      if (e.keyCode == 27) {
        $("body").css("overflow", "auto");
        $("footer").show(0);
        $(".exit").hide(100);
        $(".rightArrow").hide(100);
        $(".leftArrow").hide(100);
        $(".show").animate({
          top: "50%",
          left: "50%",
          width: "0",
          height: "0"
        }, { duration: 1000 });
      }
      else if (e.keyCode == 39  || e.keyCode == 38) {
        let currentSrc = $(".pics").children().attr("src");
        let pos = 0;
        for (let i = 0; i < 10; i++) {
          if (images[i] == currentSrc) {
            if (i == 9) {
              pos = 0;
            } else {
              pos = i + 1;
            }
          }
        }
        $(".pics").html(`<img class="w-100" src="${images[pos]}">`);
      }
      else if (e.keyCode == 37 || e.keyCode == 40) {
        let currentSrc = $(".pics").children().attr("src");
        let pos = 0;
        for (let i = 0; i < 10; i++) {
          if (images[i] == currentSrc) {
            if (i == 0) {
              pos = 9;
            } else {
              pos = i - 1;
            }
          }
        }
        $(".pics").html(`<img class="w-100" src="${images[pos]}">`);
      }
    })

    $(".exit").click(function () {
      $("body").css("overflow", "auto");
      $("footer").show(0);
      $(".exit").hide(100);
      $(".rightArrow").hide(100);
      $(".leftArrow").hide(100);
      $(".show").animate({
        top: "50%",
        left: "50%",
        width: "0",
        height: "0"
      }, { duration: 1000 });
    })

    $(".winner").click(function () {
      let src = $(this).children().attr("src");
      $(".pics").html(`<img class="w-100" src="${src}">`);
      $(".show").animate({
        top: "0",
        left: "0",
        width: "100%",
        height: "100%"
      }, { duration: 1000 });
      $("body").css("overflow", "hidden");
      $("footer").hide(0);
      $(".exit").show(1150);
      $(".rightArrow").show(1150);
      $(".leftArrow").show(1150);
    })

  }

  out(x) {
    if (x.target.src == undefined) {
      $("body").css("overflow", "auto");
      $("footer").show(0);
      $(".exit").hide(100);
      $(".rightArrow").hide(100);
      $(".leftArrow").hide(100);
      $(".show").animate({
        top: "50%",
        left: "50%",
        width: "0",
        height: "0"
      }, { duration: 1000 });
    }
  }

}
