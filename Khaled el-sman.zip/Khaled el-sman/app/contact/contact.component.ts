import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $("nav").hide(0);
    $("footer").hide(0);
    
    $("#signUp").hide(0);
    $("strong").click(function () {
      $("#logIn").hide(1000);
      $("#signUp").show(1000);
    })
    $("small").click(function () {
      $("#signUp").hide(1000);
      $("#logIn").show(1000);
    })
  }

}
