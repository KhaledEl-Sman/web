import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $("nav").show(0);
    $("footer").show(0);
    /*
    $(".voteNow").click(function () {
      let vote = $(this).parent().children().eq(0).children("span").html();
      $(this).parent().children().eq(0).children("span").html(++vote);
    })
    */
  }

}
