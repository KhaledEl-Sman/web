import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    $(window).scroll(function(){

      if ($(window).scrollTop() >= 320) {
        $(".up").css("display", "flex");
      } else {
        $(".up").css("display", "none");
      }
      
    })

    $(".up").click(function () {

      $('html, body').animate({ scrollTop: 0 }, $(window).scrollTop() / 2);

    })

  }

}
