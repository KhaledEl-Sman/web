import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    $("nav").show(0);
    $("footer").show(0);

    $(".pic").click(function () {
      let src = $(".majorImage").attr("src");
      $(".majorImage").attr("src", $(this).children().attr("src"))
      $(this).children().attr("src", src);
    })

    $(".winnerInfo a").click(function () {
      let hRef = $(this).attr("class");
      hRef = hRef.slice(0, 3);
      $('html, body').animate({ scrollTop: $("#" + hRef).offset().top - 100 }, 1000);
    })

    let cou = false;
    $(window).scroll(function () {
      if ($(window).scrollTop() >= $("#vot").offset().top - 525 && $(window).scrollTop() <= $("#vot").offset().top+35 && cou == false) {
        counter();
        cou = true;
      }

    })

    function counter() {
      $('.counter').each(function () {
        var $this = $(this), countTo = $this.attr('data-count');
        $(
          { countNum: $this.text() }).animate({
            countNum: countTo
          },
            {
              duration: 1000,
              easing: 'linear',
              step: function () {
                $this.text(Math.floor(this.countNum));
              },
              complete: function () {
                $this.text(this.countNum);
              }
            });
      });
    }


    $(".vid").hover(function () {
      $(this).children("video")[0].play();
    }, function () {
      $(this).children("video")[0].currentTime = 0;
      $(this).children("video")[0].pause();
    });


    $(".bttn").click(function () {
      let comment = $(".textar").val();
      $(".textar").val("");
      let newComment = `
      <div class="col-12 py-2 d-flex align-items-center">
      <img class="rounded-circle" src="assets/images/two.png" style="width: 40px ;">
      <p dir="rtl" class="text-muted mr-3 py-2 px-4"
          style="padding: 0; margin: 0; background-color: #d1d1d1; border-radius: 10px;display:inline-block;">
          <span dir = "rtl" style = "color:rgba(0, 0, 0, .7); cursor: pointer; font-family: 'Righteous', cursive; font-size: 15px;" >Ola Xavi </span> :  ${comment}
      </p>
      </div>`;
      if (comment.length > 1) {
        $(".newComments").append(newComment);
      }
    })

  }

}

/*
  font-family: 'Lemonada', cursive;
font-family: 'Righteous', cursive;
font-family: 'IBM Plex Sans', sans-serif;
font-family: 'El Messiri', sans-serif;
  d-flex align-items-center justify-content-center
  #05F29B







*/


/*
<meta charset="UTF-8" >
<meta name="referrer" content = "origin-when-cross-origin" />
<meta name="viewport" content = "width=device-width, initial-scale=1.0" >
<meta http - equiv="X-UA-Compatible" content = "IE=edge" >
<meta name="description" content = "Swab The World aims to increase awareness of stem cell donation and to diversify the global donor bank." >
<link rel="canonical" href = "https://www.awwwards.com/sites/swab-the-world" />
<meta name="theme-color" content = "#3ea094" >
<meta name="Keywords" content = "Awwwards are the Website Awards that recognize and promote the talent and effort of the best developers, designers and web agencies in the world." > <meta property="og:title" content = "Swab The World - Awwwards SOTD" /> <meta property="og:type" content = "website" /> <meta property="og:url" content = "https://www.awwwards.com/sites/swab-the-world" /> <meta property="og:description" content = "Swab The World aims to increase awareness of stem cell donation and to diversify the global donor bank." /> <meta property="og:image" content = "https://assets.awwwards.com/awards/sites_of_the_day/2020/02/swabtheworld-website.jpg" /> <meta name="twitter:card" content = "photo" > <meta name="twitter:site" content = "@awwwards" > <meta name="twitter:creator" content = "@awwwards" > <meta name="twitter:url" content = "https://www.awwwards.com/sites/swab-the-world" > <meta name="twitter:title" content = "Swab The World - Awwwards SOTD" > <meta name="twitter:description" content = "Swab The World aims to increase awareness of stem cell donation and to diversify the global donor bank." > <meta name="twitter:image" content = "https://assets.awwwards.com/awards/sites_of_the_day/2020/02/swabtheworld-website.jpg" > <link rel="next" href = "https://www.awwwards.com/sites/victor-work-20" > <link rel="prev" href = "https://www.awwwards.com/sites/erika-senft-miller" > <title>Swab The World - Awwwards SOTD < /title>
*/
